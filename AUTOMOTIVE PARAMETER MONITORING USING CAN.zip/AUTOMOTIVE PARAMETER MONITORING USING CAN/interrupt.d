.\interrupt.o: interrupt.c
.\interrupt.o: C:\Keil 4\ARM\Inc\Philips\lpc21xx.h
.\interrupt.o: pin_function_defines.h
.\interrupt.o: defines.h
.\interrupt.o: interrupt.h
