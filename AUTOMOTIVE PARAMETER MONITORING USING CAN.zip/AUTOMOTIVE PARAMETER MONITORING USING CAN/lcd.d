.\lcd.o: lcd.c
.\lcd.o: C:\Keil 4\ARM\Inc\Philips\LPC21xx.h
.\lcd.o: delay.h
.\lcd.o: lcd.h
.\lcd.o: defines.h
.\lcd.o: types.h
