.\mainnode.o: mainNode.c
.\mainnode.o: C:\Keil 4\ARM\Inc\Philips\lpc21xx.h
.\mainnode.o: types.h
.\mainnode.o: can.h
.\mainnode.o: can_defines.h
.\mainnode.o: lcd.h
.\mainnode.o: delay.h
.\mainnode.o: ds18b20.h
.\mainnode.o: defines.h
.\mainnode.o: interrupt.h
