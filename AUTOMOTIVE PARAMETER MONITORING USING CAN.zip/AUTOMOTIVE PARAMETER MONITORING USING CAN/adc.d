.\adc.o: ADC.c
.\adc.o: C:\Keil 4\ARM\Inc\Philips\LPC21xx.h
.\adc.o: types.h
.\adc.o: defines.h
.\adc.o: adc_defines.h
.\adc.o: delay.h
