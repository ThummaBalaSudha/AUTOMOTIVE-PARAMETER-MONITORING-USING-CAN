.\indicatornode.o: indicatorNode.c
.\indicatornode.o: C:\Keil 4\ARM\Inc\Philips\LPC21xx.h
.\indicatornode.o: delay.h
.\indicatornode.o: can.h
.\indicatornode.o: types.h
.\indicatornode.o: can_defines.h
