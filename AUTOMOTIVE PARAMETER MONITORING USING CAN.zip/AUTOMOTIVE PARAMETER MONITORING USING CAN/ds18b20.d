.\ds18b20.o: ds18b20.c
.\ds18b20.o: C:\Keil 4\ARM\Inc\Philips\LPC21xx.h
.\ds18b20.o: delay.h
