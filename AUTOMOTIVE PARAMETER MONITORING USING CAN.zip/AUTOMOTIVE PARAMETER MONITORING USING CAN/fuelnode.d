.\fuelnode.o: fuelNode.c
.\fuelnode.o: C:\Keil 4\ARM\Inc\Philips\LPC21xx.h
.\fuelnode.o: types.h
.\fuelnode.o: adc.h
.\fuelnode.o: adc_defines.h
.\fuelnode.o: delay.h
.\fuelnode.o: can.h
.\fuelnode.o: can_defines.h
